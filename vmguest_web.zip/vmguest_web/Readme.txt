Informasi Web Vmguest

Framework = Codeigniter 4
PHP = 7.4

List Extension
-Bootstrap 5
-Bootstrap Icon
-Material Design Bootstrap(MDB)
-ChartJs 3.5
-DataTable
-JQuery
-Google Fonts

Catatan

- 2 file CI4 yang satu digunakan jika mencoba website menggunakan XAMPP yang satu digunakan untuk melakukan deploy dalam linux
- Model pada CI4 yang digunakan adalah CRUD(Create,Read,Update,Delete) model.
ref = https://codeigniter.com/user_guide/models/model.html?highlight=crud
- Semua file extentions seperti bootstrap,DataTable, dan Chart menggunakan CDN yang berarti memerlukan koneksi internet agar extension dapat aktif.
- Terdapat 2 Libraries yang digunakan sebagai Konversi dan Melakukan pencarian data untuk halaman comparison.php
- Perbedaan dari kedua file tersebut adalah route yang digunakan navbar pada setiap page
Kode Navbar untuk XAMPP

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">VMGUEST</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
        <a class="nav-link" href="<?=site_url('UsersController/index')?>">Home </a>
      <li class="nav-item active">
      <li class="nav-item">
        <a class="nav-link" href=<?=site_url('UsersController/table')?>>Table & Upload</a>
      </li>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=site_url('UsersController/table_backup')?>">Comparasi<span class="sr-only">(current)</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="<?=site_url('UsersController/table_backup_all')?>">Data Backup </a>
      </li>
    </ul>
  </div>
</nav>

Kode Navbar untuk linux

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">VMGUEST</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
        <a class="nav-link" href="<?=base_url('/')?>">Home </a>
      <li class="nav-item active">
      <li class="nav-item">
        <a class="nav-link" href=<?=base_url('/table')?>>Table & Upload</a>
      </li>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('/table_backup')?>">Comparasi<span class="sr-only">(current)</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="<?=base_url('/table_backup_all')?>">Data Backup </a>
      </li>
    </ul>
  </div>
</nav>


