-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2021 at 11:52 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vmguest`
--

-- --------------------------------------------------------

--
-- Table structure for table `log_db`
--

CREATE TABLE `log_db` (
  `id_log` int(11) NOT NULL,
  `time_data` date NOT NULL,
  `count_data` int(20) NOT NULL,
  `count_on` int(10) NOT NULL,
  `count_off` int(10) NOT NULL,
  `count_current` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vmguest`
--

CREATE TABLE `vmguest` (
  `id_vmguest` int(10) NOT NULL,
  `name` varchar(500) NOT NULL,
  `state` varchar(500) NOT NULL,
  `state_int` int(10) NOT NULL,
  `status` varchar(100) NOT NULL,
  `managed` varchar(500) NOT NULL,
  `host` varchar(500) NOT NULL,
  `cluster` varchar(500) NOT NULL,
  `provisioned_space` float NOT NULL,
  `used_space` float NOT NULL,
  `guest_os` varchar(500) NOT NULL,
  `compability` varchar(500) NOT NULL,
  `memory_size` float NOT NULL,
  `reservation` int(10) NOT NULL,
  `cpu` int(10) NOT NULL,
  `nics` int(10) NOT NULL,
  `uptime` int(20) NOT NULL,
  `ip_address` varchar(500) NOT NULL,
  `vmware_tools_version_status` varchar(500) NOT NULL,
  `vmware_tools_running_status` varchar(500) NOT NULL,
  `host_cpu` float NOT NULL,
  `host_memory` float NOT NULL,
  `guest_mem` int(10) NOT NULL,
  `dns_name` varchar(500) NOT NULL,
  `evc_mode` varchar(500) NOT NULL,
  `uuid` varchar(500) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `alarm_actions` varchar(500) NOT NULL,
  `ha_protected` varchar(500) NOT NULL,
  `need_consolidation` varchar(500) NOT NULL,
  `vm_storage` varchar(500) NOT NULL,
  `encryption` varchar(500) NOT NULL,
  `tpm` varchar(100) NOT NULL,
  `vbs` varchar(100) NOT NULL,
  `time_log` varchar(100) NOT NULL,
  `count_log` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vmguest_backup`
--

CREATE TABLE `vmguest_backup` (
  `id_vmguest_backup` int(11) NOT NULL,
  `id_vmguest` int(11) NOT NULL,
  `time_data` date NOT NULL,
  `name` varchar(500) NOT NULL,
  `state` varchar(500) NOT NULL,
  `state_int` int(10) NOT NULL,
  `status` varchar(100) NOT NULL,
  `managed` varchar(500) NOT NULL,
  `host` varchar(500) NOT NULL,
  `cluster` varchar(500) NOT NULL,
  `provisioned_space` float NOT NULL,
  `used_space` float NOT NULL,
  `guest_os` varchar(500) NOT NULL,
  `compability` varchar(500) NOT NULL,
  `memory_size` float NOT NULL,
  `reservation` int(10) NOT NULL,
  `cpu` int(10) NOT NULL,
  `nics` int(10) NOT NULL,
  `uptime` int(20) NOT NULL,
  `ip_address` varchar(500) NOT NULL,
  `vmware_tools_version_status` varchar(500) NOT NULL,
  `vmware_tools_running_status` varchar(500) NOT NULL,
  `host_cpu` float NOT NULL,
  `host_memory` float NOT NULL,
  `guest_mem` int(10) NOT NULL,
  `dns_name` varchar(500) NOT NULL,
  `evc_mode` varchar(500) NOT NULL,
  `uuid` varchar(500) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `alarm_actions` varchar(500) NOT NULL,
  `ha_protected` varchar(500) NOT NULL,
  `need_consolidation` varchar(500) NOT NULL,
  `vm_storage` varchar(500) NOT NULL,
  `encryption` varchar(500) NOT NULL,
  `tpm` varchar(100) NOT NULL,
  `vbs` varchar(100) NOT NULL,
  `time_log` varchar(100) NOT NULL,
  `count_log` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vmguest_backup_all`
--

CREATE TABLE `vmguest_backup_all` (
  `id_vmguest_baclup_all` int(10) NOT NULL,
  `id_vmguest` int(11) NOT NULL,
  `time_data` date NOT NULL,
  `time_update` date NOT NULL,
  `name` varchar(500) NOT NULL,
  `state` varchar(500) NOT NULL,
  `state_int` int(10) NOT NULL,
  `status` varchar(100) NOT NULL,
  `managed` varchar(500) NOT NULL,
  `host` varchar(500) NOT NULL,
  `cluster` varchar(500) NOT NULL,
  `provisioned_space` float NOT NULL,
  `used_space` float NOT NULL,
  `guest_os` varchar(500) NOT NULL,
  `compability` varchar(500) NOT NULL,
  `memory_size` float NOT NULL,
  `reservation` int(10) NOT NULL,
  `cpu` int(10) NOT NULL,
  `nics` int(10) NOT NULL,
  `uptime` int(20) NOT NULL,
  `ip_address` varchar(500) NOT NULL,
  `vmware_tools_version_status` varchar(500) NOT NULL,
  `vmware_tools_running_status` varchar(500) NOT NULL,
  `host_cpu` float NOT NULL,
  `host_memory` float NOT NULL,
  `guest_mem` int(10) NOT NULL,
  `dns_name` varchar(500) NOT NULL,
  `evc_mode` varchar(500) NOT NULL,
  `uuid` varchar(500) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `alarm_actions` varchar(500) NOT NULL,
  `ha_protected` varchar(500) NOT NULL,
  `need_consolidation` varchar(500) NOT NULL,
  `vm_storage` varchar(500) NOT NULL,
  `encryption` varchar(500) NOT NULL,
  `tpm` varchar(100) NOT NULL,
  `vbs` varchar(100) NOT NULL,
  `time_log` varchar(100) NOT NULL,
  `count_log` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log_db`
--
ALTER TABLE `log_db`
  ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `vmguest`
--
ALTER TABLE `vmguest`
  ADD PRIMARY KEY (`id_vmguest`);

--
-- Indexes for table `vmguest_backup`
--
ALTER TABLE `vmguest_backup`
  ADD PRIMARY KEY (`id_vmguest_backup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log_db`
--
ALTER TABLE `log_db`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vmguest`
--
ALTER TABLE `vmguest`
  MODIFY `id_vmguest` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vmguest_backup`
--
ALTER TABLE `vmguest_backup`
  MODIFY `id_vmguest_backup` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
